#include <stdio.h>                                                                                      
#include <hellomake.h>

//void myDummyFn(){
//}

void myPrintHelloMake(void) {

  printf("Hello World!\n");

  return;
} 
