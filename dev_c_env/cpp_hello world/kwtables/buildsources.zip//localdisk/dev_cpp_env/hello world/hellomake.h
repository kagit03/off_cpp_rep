/*
example include file
*/

void myPrintHelloMake(void);
void myKwDemo(void); 
